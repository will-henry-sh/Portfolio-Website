<?php
/**
 * Twenty Twenty-Five WHC child theme setup.
 */

if ( ! function_exists( 'twentytwentyfive_whc_enqueue_styles' ) ) :
	/**
	 * Enqueue parent + child styles with filemtime-based cache busting.
	 *
	 * @return void
	 */
	function twentytwentyfive_whc_enqueue_styles() {
		$parent_style_path = get_template_directory() . '/style.css';
		$child_style_path  = get_stylesheet_directory() . '/style.css';

		$parent_version = file_exists( $parent_style_path ) ? filemtime( $parent_style_path ) : wp_get_theme( get_template() )->get( 'Version' );
		$child_version  = file_exists( $child_style_path ) ? filemtime( $child_style_path ) : wp_get_theme()->get( 'Version' );

		wp_enqueue_style(
			'twentytwentyfive-parent-style',
			get_template_directory_uri() . '/style.css',
			array(),
			$parent_version
		);

		wp_enqueue_style(
			'twentytwentyfive-whc-style',
			get_stylesheet_uri(),
			array( 'twentytwentyfive-parent-style' ),
			$child_version
		);
	}
endif;
add_action( 'wp_enqueue_scripts', 'twentytwentyfive_whc_enqueue_styles' );
